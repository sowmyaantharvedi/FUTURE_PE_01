# FUTURE_PE_01

## Future Interns – Prompt Engineering Task 1

### Project
Created website content and UI concept for **Coastal Brew**, a premium cafe website.

### Files
- prompt.txt
- screenshots/

### Author
Sowmya Antharvedi
